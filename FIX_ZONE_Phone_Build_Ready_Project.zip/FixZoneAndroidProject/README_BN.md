# FIX ZONE — Android Starter Project

এই ZIP-এ FIX ZONE-এর বর্তমান HTML Preview-কে Android WebView অ্যাপে চালানোর Starter Project রাখা হয়েছে।

## এখন কী আছে
- Android launcher activity এবং WebView shell
- `app/src/main/assets/index.html`-এ FIX ZONE-এর বর্তমান Preview
- Android Gradle Plugin 8.6.1 / compileSdk 35 কনফিগারেশন
- GitHub Actions-এর cloud build workflow (`.github/workflows/android.yml`)

## APK বানানোর পথ

### কম্পিউটার থাকলে
1. Android Studio-তে `FixZoneAndroidProject` ফোল্ডার Open করুন।
2. JDK 17, Android SDK 35 এবং Gradle 8.7 ব্যবহার করে Sync করুন।
3. Build > Build APK(s) নির্বাচন করুন।

### শুধু Android ফোন থাকলে
এই ZIP-এ cloud build workflow রাখা হয়েছে, কিন্তু workflow চালাতে একটি GitHub account এবং project-টি GitHub repository-তে upload করতে হবে। ফোনের browser দিয়েই GitHub ব্যবহার করা যায়; PC আবশ্যক নয়। Account তৈরি/লগইন ও upload-এর অনুমতি আপনাকেই দিতে হবে—আমি আপনার হয়ে account খুলতে বা login করতে পারি না।

Repository-তে project upload হওয়ার পর Actions tab থেকে **Build FIX ZONE APK** workflow চালানো যাবে। Build সফল হলে Actions run-এর Artifacts থেকে `FIX-ZONE-debug-apk` ডাউনলোড করা যাবে।

## গুরুত্বপূর্ণ সীমাবদ্ধতা — এটি Final Business App নয়
এই Starter Project বর্তমানে HTML Preview-কে Android WebView-তে দেখায়। নিচের ফিচারগুলো এখনো বাস্তব backend/native implementation হিসেবে যুক্ত হয়নি:
- Face/Fingerprint authentication (Android BiometricPrompt)
- Secure Admin roles, server-side permissions এবং audit log
- Encrypted Cloud Database ও Cloud/Phone backup sync
- Real FIX AI service/API
- POS, inventory, supplier stock, repair workflow, billing, SMS/WhatsApp এবং printer integration

Preview-র browser storage-কে Cloud Backup বা production-grade secure storage মনে করবেন না। বাস্তব customer data ব্যবহার করার আগে authentication, encryption, backup/restore, access control ও security testing সম্পন্ন করা জরুরি।

## App identity
- App name: FIX ZONE
- Package: `com.fixzone.app`
- Version: `1.0.0`
- Minimum Android: API 23 (Android 6.0)

এটি Debug APK তৈরির starter source। Public release-এর আগে release signing key, privacy policy, permissions review, device testing এবং security review প্রয়োজন।
